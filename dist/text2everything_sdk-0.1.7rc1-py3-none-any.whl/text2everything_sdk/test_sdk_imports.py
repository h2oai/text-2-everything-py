#!/usr/bin/env python3
"""Test that the SDK imports work correctly after the fix."""

try:
    from text2everything_sdk import Text2EverythingClient
    from text2everything_sdk.exceptions import (

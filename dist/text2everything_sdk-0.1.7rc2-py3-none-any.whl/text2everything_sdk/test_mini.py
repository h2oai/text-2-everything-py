#!/usr/bin/env python3
"""
Mini test to verify that create() returns single object for small schemas.
"""
import os
from text2everything_sdk.client import Text2EverythingClient

# Get credentials from environment
base_url = os.getenv("T2E_BASE_URL", "http://localhost:80")
access_token = os.getenv("T2E_ACCESS_TOKEN")
workspace_name = os.getenv("T2E_WORKSPACE_NAME")

if not access_token or not workspace_name:
    print("❌ Error: T2E_ACCESS_TOKEN and T2E_WORKSPACE_NAME must be set")
    exit(1)

# Create client
client = Text2EverythingClient(
    base_url=base_url,
    access_token=access_token,
    workspace_name=workspace_name
)

# Create a test project
print("Creating test project...")
project = client.projects.create(name="Mini Test Project")
project_id = project.id
print(f"✅ Project created: {project_id}")

try:
    # Test case: Small schema (≤8 columns) should return single object
    print("\nTesting small schema (4 columns)...")
    small_schema_data = {
        "table": {
            "name": "test_small_users",
            "columns": [
                {"name": "id", "type": "integer"},
                {"name": "name", "type": "string"},
                {"name": "email", "type": "string"},
                {"name": "status", "type": "string"},
            ]
        }
    }
    
    result = client.schema_metadata.create(
        project_id=project_id,
        name="Small User Table Test",
        schema_data=small_schema_data,
        description="Test schema with ≤8 columns"
    )
    
    # Check result type
    if isinstance(result, list):
        print(f"❌ FAIL: Expected single object, got list with {len(result)} items")
        print(f"   Result type: {type(result)}")
        if result:
            print(f"   First item split_group_id: {result[0].split_group_id}")
    else:
        print(f"✅ PASS: Got single object as expected")
        print(f"   Result type: {type(result).__name__}")
        print(f"   Schema ID: {result.id}")
        print(f"   split_group_id: {result.split_group_id}")
        
finally:
    # Cleanup
    print(f"\nCleaning up project {project_id}...")
    client.projects.delete(project_id)
    print("✅ Cleanup complete")
